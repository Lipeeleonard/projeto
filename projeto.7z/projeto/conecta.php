<?php
    $conn = mysqli_connect("sql.freedb.tech","freedb_lipeeleonard","RHptV@3#!7uctyZ","freedb_luizin");
    mysqli_set_charset($conn,"utf8");
    if (!$conn) {
        echo "Error: Falha ao conectar-se ao servidor!".PHP_EOL;
        echo "Error: Falha ".mysqli_connect_error().PHP_EOL;
    }


?>